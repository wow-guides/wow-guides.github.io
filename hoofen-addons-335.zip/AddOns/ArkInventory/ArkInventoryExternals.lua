-- load required libraries for disembedded
LoadAddOn( "Ace3" )
LoadAddOn( "Ace2" )
LoadAddOn( "Dewdrop-2.0" )
LoadAddOn( "LibPeriodicTable-3.1" )
LoadAddOn( "LibSharedMedia-3.0" )
LoadAddOn( "LibBabble-Zone-3.0" )
