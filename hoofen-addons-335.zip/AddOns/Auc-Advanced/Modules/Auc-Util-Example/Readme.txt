This is an AddOn which is meant as an example of Auctioneer's embeddable
module support. You may either install this addon in WoW's AddOn folder,
or drop it into Auctioneer's "modules" subdirectory and either:
  * Execute ../luae.exe (or ../rebuild.pl if you have perl), which will
    automatically generate a ../Active.xml with all installed modules
	enabled, and/or
  * Manually edit the existing ../Active.xml and add/remove entries
    to your taste.


