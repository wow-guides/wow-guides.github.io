DBM:RegisterMapSize("HallsofLightning",
	1, 566.235015869, 377.48999023,	-- Unyielding Garrison
	2, 708.23701477, 472.160034177	-- Walk of the Makers
)
