DBM:RegisterMapSize("Gundrak", 1, 905.033050542, 603.35009766) -- Gundrak
